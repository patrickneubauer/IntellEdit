package test3;

public class Constructor2 extends SuperConsturctor {
    static String str = null;
    int i = 0;
    public Constructor2() {}
}
