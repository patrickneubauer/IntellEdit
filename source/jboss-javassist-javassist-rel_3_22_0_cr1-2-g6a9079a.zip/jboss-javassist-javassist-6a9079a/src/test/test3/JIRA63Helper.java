package test3;

public class JIRA63Helper {
    public static JIRA63Helper getAnObject(Object o) {
        return new JIRA63Helper();
    }
}
