package test1;

public class MakeClass {
    public int p;

    public MakeClass() {
	p = 3;
    }
}
